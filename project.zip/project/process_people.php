<?php
require 'db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recibir datos del formulario
    $full_name = $_POST['full_name'] ?? null;
    $phone = $_POST['phone'] ?? null;
    $mail = $_POST['mail'] ?? null;
    $gender = $_POST['gender'] ?? null;
    $age_group = $_POST['age_group'] ?? null;
    $sisben_description = $_POST['sisben_id'] ?? null;
    $marital_status_name = $_POST['status_name'] ?? null;
    $differential_focus_ids = $_POST['differential_focus'] ?? [];
    $level_name = $_POST['level_name'] ?? null;

    // Validaciones básicas
    if (!$full_name || !$phone || !$mail || !$gender || !$age_group || !$sisben_description || !$level_name) {
        die("Error: Todos los campos son obligatorios.");
    }

    try {
        // Iniciar transacción
        $pdo->beginTransaction();

        // Insertar en sisben
        $stmt = $pdo->prepare("INSERT INTO sisben (description) VALUES (?)");
        $stmt->execute([$sisben_description]);
        $sisben_id = $pdo->lastInsertId();

        // Insertar en marital_statuses
        $stmt = $pdo->prepare("INSERT INTO marital_statuses (status_name) VALUES (?)");
        $stmt->execute([$marital_status_name]);
        $marital_status_id = $pdo->lastInsertId();

        // Insertar en people
        $stmt = $pdo->prepare("
            INSERT INTO people (full_name, phone, mail, gender, age_group, sisben_id, marital_status_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$full_name, $phone, $mail, $gender, $age_group, $sisben_id, $marital_status_id]);
        $people_id = $pdo->lastInsertId();

        // Insertar en educational_levels
        $stmt = $pdo->prepare("INSERT INTO educational_levels (people_id, level_name) VALUES (?, ?)");
        $stmt->execute([$people_id, $level_name]);

        // Procesar selección múltiple de enfoques diferenciales
        if (is_array($differential_focus_ids)) {
            $stmt = $pdo->prepare("INSERT INTO differential_focus_id (people_id, focus_name) VALUES (?, ?)");
            foreach ($differential_focus_ids as $focus_id) {
                $stmt->execute([$people_id, $focus_id]);
            }
        }

        // Confirmar transacción
        $pdo->commit();
        echo "Datos registrados exitosamente.";
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $pdo->rollBack();
        echo "Error: " . $e->getMessage();
    }
}
?>
