<?php
require 'db_config.php'; // Conexión a la base de datos

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qr_data = $_POST['qr_data'];
    $event_name = $_POST['event_name'];

    try {
        // Extraer el ID de la persona del QR
        preg_match('/ID: (\d+)/', $qr_data, $matches);
        if (!isset($matches[1])) {
            throw new Exception('Datos de QR no válidos.');
        }
        $people_id = $matches[1];

        // Registrar el evento
        $stmt = $pdo->prepare("INSERT INTO scan_events (people_id, event_name) VALUES (?, ?)");
        $stmt->execute([$people_id, $event_name]);

        echo json_encode([
            'status' => 'success',
            'message' => 'Escaneo registrado correctamente.',
            'data' => [
                'scan_id' => $pdo->lastInsertId(),
                'people_id' => $people_id,
                'event_name' => $event_name,
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage(),
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Método no permitido. Usa POST.',
    ]);
}
?>
