<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Plan de Desarrollo</title>
</head>
<body>
    <h1>Registrar Plan de Desarrollo</h1>
    <form action="process_plan.php" method="POST">
        <label for="plan_name">Nombre del plan:</label>
        <input type="text" id="plan_name" name="plan_name" required><br><br>

        <label for="description">Descripción:</label>
        <textarea id="description" name="description" required></textarea><br><br>

        <button type="submit">Registrar</button>
    </form>
</body>
</html>
