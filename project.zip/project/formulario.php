<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Formulario de Registro</title>
</head>
<body>
  <h1>Formulario de Registro de Persona</h1>
  <form action="insert.php" method="POST">
    <!-- Sección People -->
    <h2>Información General (Tabla: people)</h2>
    <label for="people_id">Cédula:</label>
    <input type="number" id="people_id" name="people_id" required><br>
    <label for="full_name">Nombre Completo:</label>
    <input type="text" id="full_name" name="full_name" required><br>
    <label for="phone">Teléfono:</label>
    <input type="text" id="phone" name="phone" required><br>
    <label for="mail">Correo Electrónico:</label>
    <input type="email" id="mail" name="mail" required><br>
    <label for="gender">Género:</label>
    <select id="gender" name="gender" required>
      <option value="Masculino">Masculino</option>
      <option value="Femenino">Femenino</option>
      <option value="Otro">Otro</option>
      <option value="Prefiero no decirlo">Prefiero no decirlo</option>
    </select><br>
    <label for="age_group">Grupo de Edad:</label>
    <select id="age_group" name="age_group" required>
      <option value="Niños">Niños</option>
      <option value="Adultos Jovenes">Adultos Jóvenes</option>
      <option value="Adultez media">Adultez Media</option>
      <option value="Adultos mayores (60 o mas años)">Adultos Mayores</option>
    </select><br>

    <!-- Sección Activities -->
    <h2>Actividades (Tabla: activities)</h2>
    <label for="activity_details">Detalles de la Actividad:</label>
    <textarea id="activity_details" name="activity_details"></textarea><br>

    <!-- Sección Contact -->
    <h2>Contacto (Tabla: contact)</h2>
    <label for="main_phone">Teléfono Principal:</label>
    <input type="text" id="main_phone" name="main_phone"><br>
    <label for="secondary_phone">Teléfono Secundario:</label>
    <input type="text" id="secondary_phone" name="secondary_phone"><br>
    <label for="email_contact">Correo Electrónico:</label>
    <input type="email" id="email_contact" name="email_contact"><br>
    <label for="residence_address">Dirección de Residencia:</label>
    <input type="text" id="residence_address" name="residence_address"><br>

    <!-- Sección Contractor -->
    <h2>Contratista (Tabla: contractor)</h2>
    <label for="entity">Entidad:</label>
    <input type="text" id="entity" name="entity"><br>
    <label for="contract_type">Tipo de Contrato:</label>
    <input type="text" id="contract_type" name="contract_type"><br>
    <label for="department">Departamento:</label>
    <input type="text" id="department" name="department"><br>

    <!-- Sección Differential Focus -->
    <h2>Enfoque Diferencial (Tabla: differential_focus_id)</h2>
    <label for="focus_name">Enfoque:</label>
    <select id="focus_name" name="focus_name">
      <?php
      // Conexión a la base de datos y carga de enfoques dinámicamente
      $pdo = new PDO("mysql:host=127.0.0.1;dbname=base_data_people;charset=utf8mb4", 'root', '');
      $stmt = $pdo->query("SELECT focus_id, focus_name FROM focus_types");
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
          echo "<option value='{$row['focus_id']}'>{$row['focus_name']}</option>";
      }
      ?>
    </select><br>

    <!-- Sección Emergency -->
    <h2>Información de Emergencia (Tabla: emergency)</h2>
    <label for="blood_type">Tipo de Sangre:</label>
    <input type="text" id="blood_type" name="blood_type"><br>
    <label for="contact_name">Nombre del Contacto:</label>
    <input type="text" id="contact_name" name="contact_name"><br>
    <label for="contact_phone">Teléfono del Contacto:</label>
    <input type="text" id="contact_phone" name="contact_phone"><br>
    <label for="contact_relationship">Relación:</label>
    <input type="text" id="contact_relationship" name="contact_relationship"><br>

    <!-- Sección Educational Levels -->
    <h2>Nivel Educativo (Tablas: educational_levels y educational_level_types)</h2>
    <label for="level_id">Nivel Educativo:</label>
    <select id="level_id" name="level_id" required>
      <?php
      // Conexión a la base de datos y carga de enfoques dinámicamente
      $pdo = new PDO("mysql:host=127.0.0.1;dbname=base_data_people;charset=utf8mb4", 'root', '');
      // Carga de niveles educativos dinámicamente
      $stmt = $pdo->query("SELECT level_id, level_name FROM educational_level_types");
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
          echo "<option value='{$row['level_id']}'>{$row['level_name']}</option>";
      }
      ?>
    </select><br>

    <!-- Sección Training -->
    <h2>Formación (Tabla: training)</h2>
    <label for="technical_title">Título Técnico:</label>
    <input type="text" id="technical_title" name="technical_title"><br>
    <label for="professional_title">Título Profesional:</label>
    <input type="text" id="professional_title" name="professional_title"><br>
    <label for="postgraduate_degree">Título de Posgrado:</label>
    <input type="text" id="postgraduate_degree" name="postgraduate_degree"><br>

    <!-- Botón de Envío -->
    <button type="submit">Guardar</button>
  </form>
</body>
</html>
