<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario People</title>
</head>
<body>
    <h1>Registrar Persona</h1>
    <form action="process_people.php" method="POST">
        <label for="full_name">Nombre completo:</label>
        <input type="text" id="full_name" name="full_name" required><br><br>

        <label for="phone">Teléfono:</label>
        <input type="number" id="phone" name="phone" required><br><br>

        <label for="mail">Correo:</label>
        <input type="email" id="mail" name="mail" required><br><br>

        <label for="gender">Género:</label>
        <select id="gender" name="gender" required>
            <option value="Masculino">Masculino</option>
            <option value="Femenino">Femenino</option>
            <option value="Otro">Otro</option>
            <option value="Prefiero no decirlo">Prefiero no decirlo</option>
        </select><br><br>

        <label for="age_group">Grupo de edad:</label>
        <select id="age_group" name="age_group" required>
            <option value="Adultos mayores (60 o mas años)">Adultos mayores (60 o mas años)</option>
            <option value="Adultez media">Adultez media</option>
            <option value="Adultos Jovenes">Adultos Jovenes</option>
            <option value="Niños">Niños</option>
        </select><br><br>

        <label for="sisben_id"> ¿Es sisbenizado?:</label>
        <select id="sisben_id" name="sisben_id" required>
            <option value="si">si</option>
            <option value="no">no</option>
        </select><br><br>

        <label for="status_name">Estado civil:</label>
        <select id="status_name" name="status_name" required>
            <option value="soltero(@)">Soltero(@)</option>
            <option value="casdo(@)">Casado(@)</option>
            <option value="union libre">Union libre</option>
            <option value="viudo(@)">Viudo(@)</option>
            <option value="separado(@)">Separado(@)</option>
        </select><br><br>

        <label for="focus_name">Enfoques diferenciales:</label>
<select id="focus_name" name="focus_name[]" multiple required>
    <option value="personas en condicion de discapacidad">Personas en condisiones de discapacidad</option>
    <option value="reintegrado">Reintegrado</option>
    <option value="poblacion victima del conflicto armado">Víctima del conflicto armado</option>
    <option value="extrema pobreza">Extrema pobreza</option>
    <option value="poblacion LGBTIQ">LGBTIQ+</option>
    <option value="mujeres cabeza de familia">Mujeres cabeza de hogar</option>
    <option value="adultos mayores">adultos mayores</option>
    <option value="desmovilizado">Desmovilizado</option>
    <option value="ninos ninas y adolecentes">niños y niñas adolecentes</option>
</select>
<small>Usa Ctrl (Cmd en Mac) para seleccionar múltiples opciones.</small>
<br><br>

<label for="level_name">Nivel Academico:</label>
        <select id="level_name" name="level_name" required>
            <option value="universitaria">Universitaria</option>
            <option value="tecnica o tecnologica">Tecnica o tecnologica</option>
            <option value="secundaria incompleta">Secundaria incompleta</option>
            <option value="secundaria completa">Secundaria completa</option>
            <option value="primaria incompleta">Primaria incompleta</option>
            <option value="primaria completa">Primaria completa</option>
            <option value="ninguna">Ninguna</option>
        </select><br><br> 


        <button type="submit">Registrar</button>
    </form>
</body>
</html>
