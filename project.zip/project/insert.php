<?php
// Conexión a la base de datos
$host = '127.0.0.1';
$dbname = 'base_data_people';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar con la base de datos: " . $e->getMessage());
}

// Obtener datos del formulario
$people_id = $_POST['people_id'];
$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$mail = $_POST['mail'];
$gender = $_POST['gender'];
$age_group = $_POST['age_group'];

try {
    $pdo->beginTransaction();

    // Insertar en la tabla `people`
    $stmt = $pdo->prepare("INSERT INTO people (people_id, full_name, phone, mail, gender, age_group) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$people_id, $full_name, $phone, $mail, $gender, $age_group]);

    // Insertar en la tabla `activities`
    if (!empty($_POST['activity_details'])) {
        $stmt = $pdo->prepare("INSERT INTO activities (people_id, activity_details) VALUES (?, ?)");
        $stmt->execute([$people_id, $_POST['activity_details']]);
    }

    // Insertar en la tabla `contact`
    if (!empty($_POST['main_phone']) || !empty($_POST['secondary_phone']) || !empty($_POST['email_contact'])) {
        $stmt = $pdo->prepare("INSERT INTO contact (people_id, main_phone, secondary_phone, email, residence_address) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$people_id, $_POST['main_phone'], $_POST['secondary_phone'], $_POST['email_contact'], $_POST['residence_address']]);
    }

    // Insertar en la tabla `contractor`
    if (!empty($_POST['entity'])) {
        $stmt = $pdo->prepare("INSERT INTO contractor (people_id, entity, contract_type, department) VALUES (?, ?, ?, ?)");
        $stmt->execute([$people_id, $_POST['entity'], $_POST['contract_type'], $_POST['department']]);
    }

    // Insertar en la tabla `differential_focus_id`
    if (!empty($_POST['focus_name'])) {
        $stmt = $pdo->prepare("INSERT INTO differential_focus_id (people_id, focus_name) VALUES (?, ?)");
        $stmt->execute([$people_id, $_POST['focus_name']]);
    }

    // Insertar en la tabla `emergency`
    if (!empty($_POST['blood_type']) || !empty($_POST['contact_name'])) {
        $stmt = $pdo->prepare("INSERT INTO emergency (people_id, blood_type, contact_name, contact_phone, contact_relationship) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$people_id, $_POST['blood_type'], $_POST['contact_name'], $_POST['contact_phone'], $_POST['contact_relationship']]);
    }

    // Insertar en la tabla `people_focus`
    if (!empty($_POST['focus_ids'])) {
        $focus_ids = $_POST['focus_ids'];

        foreach ($focus_ids as $focus_id) {
            // Verificar si el enfoque existe
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM focus_types WHERE focus_id = ?");
            $stmt->execute([$focus_id]);
            if ($stmt->fetchColumn() == 0) {
                die("Error: El enfoque con ID $focus_id no existe.");
            }

            // Insertar el enfoque en `people_focus`
            $stmt = $pdo->prepare("INSERT INTO people_focus (people_id, focus_id) VALUES (?, ?)");
            $stmt->execute([$people_id, $focus_id]);
        }
    }

    // Insertar en la tabla `educational_levels`
    if (!empty($_POST['level_id'])) {
        $level_id = $_POST['level_id'];
        // $educational_levels_id = $_POST['educational_levels_id'] ?? null; // Asignar null si no existe

        // Verificar si el nivel educativo ya existe
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM educational_levels WHERE level_id = ? AND people_id = ?");
        $stmt->execute([$level_id, $people_id]);

        if ($stmt->fetchColumn() == 0) {
            $stmt = $pdo->prepare("INSERT INTO educational_levels (educational_levels_id, people_id, level_id) VALUES (NULL, ?, ?)");
            $stmt->execute([$people_id, $level_id]);
        }
    }

    // Insertar en la tabla `training`
    if (!empty($_POST['technical_title']) || !empty($_POST['professional_title']) || !empty($_POST['postgraduate_degree'])) {
        $stmt = $pdo->prepare("INSERT INTO training (people_id, educational_levels_id, technical_title, professional_title, postgraduate_degree) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$people_id, $_POST['educational_levels_id'], $_POST['technical_title'], $_POST['professional_title'], $_POST['postgraduate_degree']]);
    }

    $pdo->commit();
    echo "Datos guardados exitosamente.";
} catch (Exception $e) {
    $pdo->rollBack();
    die("Error al guardar los datos: " . $e->getMessage());
}
?>
