<?php
require 'db_config.php'; // Conexión a la base de datos
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Escaneos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Panel de Escaneos</h1>
    <form method="GET" class="row mb-4">
        <div class="col-md-4">
            <label for="start_date" class="form-label">Fecha de inicio</label>
            <input type="date" class="form-control" name="start_date" id="start_date" value="<?php echo $_GET['start_date'] ?? ''; ?>">
        </div>
        <div class="col-md-4">
            <label for="end_date" class="form-label">Fecha de fin</label>
            <input type="date" class="form-control" name="end_date" id="end_date" value="<?php echo $_GET['end_date'] ?? ''; ?>">
        </div>
        <div class="col-md-4">
            <label for="event_name" class="form-label">Nombre del evento</label>
            <input type="text" class="form-control" name="event_name" id="event_name" placeholder="Filtrar por evento" value="<?php echo $_GET['event_name'] ?? ''; ?>">
        </div>
        <div class="col-12 mt-3">
            <button type="submit" class="btn btn-primary w-100">Filtrar</button>
        </div>
    </form>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Persona</th>
            <th>Evento</th>
            <th>Fecha y hora</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // Filtros de búsqueda
        $whereClauses = [];
        $params = [];

        if (!empty($_GET['start_date'])) {
            $whereClauses[] = "scan_time >= ?";
            $params[] = $_GET['start_date'] . ' 00:00:00';
        }
        if (!empty($_GET['end_date'])) {
            $whereClauses[] = "scan_time <= ?";
            $params[] = $_GET['end_date'] . ' 23:59:59';
        }
        if (!empty($_GET['event_name'])) {
            $whereClauses[] = "event_name LIKE ?";
            $params[] = '%' . $_GET['event_name'] . '%';
        }

        $where = $whereClauses ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

        // Consulta a la base de datos
        $stmt = $pdo->prepare("
            SELECT 
                scan_events.scan_id, 
                people.full_name, 
                scan_events.event_name, 
                scan_events.scan_time 
            FROM scan_events
            JOIN people ON scan_events.people_id = people.people_id
            $where
            ORDER BY scan_events.scan_time DESC
        ");
        $stmt->execute($params);

        // Mostrar resultados
        $results = $stmt->fetchAll();
        if ($results) {
            foreach ($results as $row) {
                echo "<tr>
                        <td>{$row['scan_id']}</td>
                        <td>{$row['full_name']}</td>
                        <td>{$row['event_name']}</td>
                        <td>{$row['scan_time']}</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4' class='text-center'>No se encontraron registros.</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
