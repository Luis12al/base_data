<?php
require 'db_config.php';
require 'vendor/autoload.php'; // Asegúrate de incluir la librería
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plan_name = $_POST['plan_name'];
    $description = $_POST['description'];

    try {
        // Insertar datos en la base de datos
        $stmt = $pdo->prepare("INSERT INTO plan_desarrollo (plan_name, description) VALUES (?, ?)");
        $stmt->execute([$plan_name, $description]);

        // Obtener el ID generado automáticamente
        $plan_id = $pdo->lastInsertId();

        // Generar el código QR
        $qrData = "ID: $plan_id | Plan: $plan_name | Descripción: $description";
        $qrCode = QrCode::create($qrData)
            ->setWriter(new PngWriter())
            ->setSize(300)
            ->setMargin(10)
            ->setEncoding(new \Endroid\QrCode\Encoding\Encoding('UTF-8'));

        // Ruta donde se guardará el QR
        $qrPath = "qrcodes/plan_$plan_id.png";

        // Guardar el QR en la carpeta
        $qrCode->getWriter()->writeFile($qrCode, $qrPath);

        echo "Plan registrado exitosamente. <br>";
        echo "<img src='$qrPath' alt='Código QR'><br>";
        echo "<a href='$qrPath' download>Descargar QR</a>";
    } catch (PDOException $e) {
        echo "Error al registrar: " . $e->getMessage();
    }
}
?>
